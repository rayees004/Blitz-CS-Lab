/* =========================================================
   ORBITAL SYSTEMS — mock in-memory intranet "backend"
   All data is fictional and lives only in the browser.
   ========================================================= */

const ORBITAL_EMPLOYEES = [
  { id: 1, name: "Diane Foster", title: "Chief Financial Officer", dept: "Executive", email: "d.foster@orbitalsystems.example",
    phone: "x1001", location: "HQ - Floor 9", manager: null,
    // FLAG 1 lives in a field that should only be visible to HR/the employee themselves.
    // The employee directory link (employee.html?id=N) renders this field for ANY id with
    // no check that the viewer is HR or the employee in question — broken access control.
    confidential: "Annual comp band: L9 ($310,000 base + equity). Background check ref: BGC-2291. HR-only token: BLITZ{1d0r_3mpl0y33_pr0f1l3}" },
  { id: 2, name: "John Mathews", title: "Senior Software Engineer", dept: "Engineering", email: "j.mathews@orbitalsystems.example",
    phone: "x2044", location: "HQ - Floor 4", manager: "Priya Anand",
    confidential: "Annual comp band: L5 ($142,000 base). Background check ref: BGC-1187." },
  { id: 3, name: "Sarah Wilson", title: "Product Manager", dept: "Product", email: "s.wilson@orbitalsystems.example",
    phone: "x2091", location: "HQ - Floor 5", manager: "Marcus Webb",
    confidential: "Annual comp band: L6 ($151,500 base). Background check ref: BGC-1354." },
  { id: 4, name: "David Miller", title: "IT Support Specialist", dept: "IT", email: "d.miller@orbitalsystems.example",
    phone: "x3012", location: "HQ - Floor 2", manager: "Renee Ortiz",
    confidential: "Annual comp band: L4 ($78,200 base). Background check ref: BGC-1490." },
  { id: 5, name: "Alex Thomas", title: "HR Generalist", dept: "Human Resources", email: "a.thomas@orbitalsystems.example",
    phone: "x1550", location: "HQ - Floor 3", manager: "Renee Ortiz",
    confidential: "Annual comp band: L5 ($89,000 base). Background check ref: BGC-1602." },
  { id: 6, name: "Priya Anand", title: "Engineering Manager", dept: "Engineering", email: "p.anand@orbitalsystems.example",
    phone: "x2010", location: "HQ - Floor 4", manager: "Diane Foster",
    confidential: "Annual comp band: L7 ($198,000 base). Background check ref: BGC-0994." },
  { id: 7, name: "Marcus Webb", title: "Director of Product", dept: "Product", email: "m.webb@orbitalsystems.example",
    phone: "x2200", location: "HQ - Floor 5", manager: "Diane Foster",
    confidential: "Annual comp band: L8 ($225,000 base). Background check ref: BGC-0871." },
  { id: 8, name: "Renee Ortiz", title: "VP of People & IT", dept: "Operations", email: "r.ortiz@orbitalsystems.example",
    phone: "x1000", location: "HQ - Floor 9", manager: null,
    confidential: "Annual comp band: L9 ($295,000 base + equity). Background check ref: BGC-0703." }
];

/* Login accounts — the account username/password grants access to the
   intranet but does NOT restrict which employee records that account can
   later view via the directory (that's the vulnerability). */
const ORBITAL_ACCOUNTS = [
  { employeeId: 2, username: "jmathews", password: "Engineer#2024" },
  { employeeId: 3, username: "swilson",  password: "ProductPM!55" },
  { employeeId: 4, username: "dmiller",  password: "ITSupport99" },
  { employeeId: 5, username: "athomas",  password: "PeopleFirst1" }
];

/* Mock nested "filesystem" for the document viewer.
   /public/...  -> what the Documents page normally links to
   /private/... -> not linked from any UI, only reachable via traversal */
const ORBITAL_FILES = {
  "public/employee-handbook.pdf":
    "ORBITAL SYSTEMS — EMPLOYEE HANDBOOK (Rev. 4.2)\n\nSection 1: Welcome to Orbital Systems\nSection 2: Code of Conduct\nSection 3: Time Off & Leave Policy\nSection 4: Benefits Overview\nSection 5: Workplace Safety\n\n[This is a placeholder training document — 42 pages omitted]",
  "public/company-policy.pdf":
    "ORBITAL SYSTEMS — ACCEPTABLE USE POLICY\n\nAll company systems are provided for business use. Employees must not share credentials, install unauthorized software, or attempt to access systems or data outside their authorization level.\n\n[This is a placeholder training document]",
  "public/meeting-notes.txt":
    "Weekly Eng Sync — 2026-09-08\nAttendees: Priya Anand, John Mathews, 2 others\n\n- Migration to new build pipeline on track for Sept 30\n- Reminder: Q3 performance reviews due next Friday\n- Office WiFi upgrade scheduled for this weekend (expect brief outages)",
  "private/backup-notes.txt":
    "IT BACKUP ROTATION — INTERNAL\n\nNightly backups run at 02:00 EST to the secondary datacenter.\nRestore requests must go through the #it-helpdesk channel.\nLast verified restore test: 2026-08-29 (David Miller).\nThis file is not intended to be publicly linked from the documents page.",
  "private/internal-secret.txt":
    "CONFIDENTIAL — IT INTERNAL USE ONLY\n\nThis file lives outside the public documents directory and should never be\nreachable through the normal document viewer. If you're reading this, the\nfile path was not properly validated before being read from the mock\nfilesystem — a classic path/directory traversal flaw.\n\nTraining token: BLITZ{path_orbital_trav3rs4l_77c1}"
};

const ORBITAL_PUBLIC_DOCS = [
  { file: "employee-handbook.pdf", label: "Employee Handbook", icon: "📘", size: "1.4 MB" },
  { file: "company-policy.pdf", label: "Acceptable Use Policy", icon: "📄", size: "220 KB" },
  { file: "meeting-notes.txt", label: "Weekly Eng Sync Notes", icon: "📝", size: "4 KB" }
];

const ORBITAL_ANNOUNCEMENTS = [
  { title: "Office WiFi Upgrade This Weekend", date: "2026-09-12", body: "IT will be upgrading wireless access points across Floors 2-5 this Saturday. Expect brief connectivity interruptions between 8-10am." },
  { title: "Q3 Performance Reviews Due Friday", date: "2026-09-10", body: "Managers: please complete Q3 review forms in the HR portal by end of day Friday. Reach out to HR with any questions." },
  { title: "New Badge Readers Installed", date: "2026-09-03", body: "Updated badge readers are now active at all HQ entrances. Contact IT Support if your badge is not recognized." },
  { title: "Annual Benefits Enrollment Opens Oct 1", date: "2026-08-28", body: "Open enrollment for 2027 benefits runs October 1-15. Watch your inbox for a link to the enrollment portal." }
];

const ORBITAL_TICKETS = [
  { id: 401, subject: "Monitor not turning on", status: "open", submittedBy: "David Miller", date: "2026-09-14" },
  { id: 402, subject: "VPN keeps disconnecting", status: "open", submittedBy: "John Mathews", date: "2026-09-13" },
  { id: 403, subject: "Need access to design shared drive", status: "closed", submittedBy: "Sarah Wilson", date: "2026-09-08" }
];

/* ---- API helpers ---- */
const OrbitalAPI = {
  getEmployeeById(id) {
    return ORBITAL_EMPLOYEES.find(e => Number(e.id) === Number(id)) || null;
  },
  getAllEmployees() { return ORBITAL_EMPLOYEES; },
  findAccount(username, password) {
    const acct = ORBITAL_ACCOUNTS.find(a => a.username === username && a.password === password);
    if (!acct) return null;
    return { account: acct, employee: this.getEmployeeById(acct.employeeId) };
  },
  /* VULNERABLE BY DESIGN: resolves "public/<file>" but does not strip or
     validate ../ sequences (or absolute-looking paths) in the file param
     before doing the lookup, so a crafted value can escape the intended
     "public/" prefix and reach files under "private/". */
  readDocument(userFileParam) {
    const raw = String(userFileParam || "");
    // naive prefixing — the actual bug:
    let resolvedPath = "public/" + raw;
    // extremely naive traversal "resolution" so ../ sequences move up a
    // directory level, mirroring how a real path.join / path.resolve bug behaves
    const parts = resolvedPath.split("/");
    const stack = [];
    for (const part of parts) {
      if (part === "..") stack.pop();
      else if (part === "." || part === "") continue;
      else stack.push(part);
    }
    resolvedPath = stack.join("/");
    return { path: resolvedPath, content: ORBITAL_FILES[resolvedPath] || null };
  },
  getPublicDocs() { return ORBITAL_PUBLIC_DOCS; },
  getAnnouncements() { return ORBITAL_ANNOUNCEMENTS; },
  getTickets() { return ORBITAL_TICKETS; }
};

const OrbitalSession = {
  KEY: "orbital_session_empid",
  login(employeeId) { localStorage.setItem(this.KEY, String(employeeId)); },
  logout() { localStorage.removeItem(this.KEY); },
  currentEmployeeId() {
    const v = localStorage.getItem(this.KEY);
    return v ? Number(v) : null;
  },
  currentEmployee() {
    const id = this.currentEmployeeId();
    return id ? OrbitalAPI.getEmployeeById(id) : null;
  },
  isLoggedIn() { return this.currentEmployeeId() !== null; }
};
