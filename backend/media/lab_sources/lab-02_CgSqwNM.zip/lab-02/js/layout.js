function orbitalRenderHeader(active) {
  const emp = OrbitalSession.currentEmployee();
  const initials = emp ? emp.name.split(" ").map(w => w[0]).join("").slice(0,2).toUpperCase() : "?";
  const items = [
    ["index.html", "Home"],
    ["employees.html", "Directory"],
    ["documents.html", "Documents"],
    ["announcements.html", "Announcements"],
    ["support.html", "Support"]
  ];
  const navHtml = items.map(([href, label]) =>
    `<a href="${href}" class="${active===label?'active':''}">${label}</a>`
  ).join("");

  document.write(`
  <header class="ob-header">
    <div class="ob-header-inner">
      <a href="index.html" class="ob-logo"><span class="dot"></span> ORBITAL SYSTEMS</a>
      <nav class="ob-header-nav">${navHtml}</nav>
      <div class="ob-header-user">
        ${emp ? `<span>Welcome, <b>${emp.name.split(' ')[0]}</b></span><a href="profile.html" class="ob-avatar">${initials}</a>`
              : `<a href="login.html" class="ob-btn small">Sign In</a>`}
      </div>
    </div>
  </header>
  `);
}
